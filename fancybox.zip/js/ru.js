// JavaScript Document

var C_CLOSE_BTN = 'ЗАКРЫТЬ';
var C_SITE_MESSAGE = 'ИНФОРМАЦИЯ С САЙТА';